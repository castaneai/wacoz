var preservedLivesDict = {};

var openWatchPage = function (liveID) {
    var url = "http://live.nicovideo.jp/watch/lv" + liveID;
    chrome.tabs.create({url: url});
};

var enterLive = function (liveID) {
    var url = "http://live.nicovideo.jp/api/getplayerstatus?v=lv" + liveID;
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState != 4) return;
        var xml = xhr.responseXML;
        chrome.notifications.create(liveID.toString(), {
            type: "image",
            iconUrl: xml.getElementsByTagName("thumb_url")[0].nodeValue,
            title: xml.getElementsByTagName("title")[0].nodeValue,
            message: "座席取得に成功しました．" +
            xml.getElementsByTagName("room_label")[0].nodeValue +
            " - " + xml.getElementsByTagName("room_seetno")[0].nodeValue
        });
    };
    xhr.send(null);
};


/**
 * 生放送の座席取得を予約する
 * @param liveId
 * @param startTime
 */
function preserve(liveId, startTime) {
    preservedLivesDict[liveId] = startTime;
    chrome.alarms.create(liveId.toString(), {
        when: startTime +
    })
}

/**
 * 予約をキャンセルする
 * 予約されていない放送をキャンセルしても何も起こらない
 * @param liveId
 */
function cancel(liveId) {
    if (typeof(preservedLivesDict[liveId]) !== 'undefined') {
        delete preservedLivesDict[liveId];
    }
}
